import React from "react";
import s from "./setting.module.css";
const Setting = ()=>{

    return (
        <>
            <h1>Setting</h1>
        </>
    )
}

export default Setting;