import React from "react";
import s from "./order.module.css";

const Order = ()=>{

    return (
        <>
            <h1>Order</h1>
        </>
    )
}

export default Order;