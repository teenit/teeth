import React from "react";
import s from "./happyBD.module.css";

const HappyBD = ()=>{

    return (
        <>
            <h1>HappyBD</h1>
        </>
    )
}

export default HappyBD;