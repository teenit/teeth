import React from "react";
import s from "./notification.module.css";

const Notification = ()=>{

    return (
        <>
            <h1>Notification</h1>
        </>
    )
}

export default Notification;