import React from "react";
import s from "./controlPanel.module.css";
const ControlPanel = ()=>{

    return (
        <>
            <h1>ControlPanel</h1>
        </>
    )
}

export default ControlPanel;