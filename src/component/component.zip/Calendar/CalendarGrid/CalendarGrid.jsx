import React from "react";

import s from "./CalendarGrid.module.css";

const CalendarGrid = ({startDay,momentTime,momentStart})=>{
    const day = startDay.clone();
    const cells = [...Array(42)].map((item,i)=>day.add(1,'day').clone())
    const nameWeek = ["ПН","ВТ","СР","ЧТ","ПТ","СБ","НД"];
    const weekend = (item) => item.day() == 6 || item.day() == 0 ? s.weekend : null;
    const currentDay = (item) => momentStart.isSame(item,'day') ? s.curren__day : null;
    const currentMonth = (item) => momentTime.isSame(item,'month') ? s.curren__month : null;
    return(
        <div className={s.wr}>
            <div className={s.name__week}>
                    {
                        nameWeek.map((item,index)=><div key={item} className={s.week__day}>{item}</div>)
                    }
            </div>
        <div className={s.wrap}>
            <div className={s.inner}>
                {
                    cells.map((item,index)=>{
                        return(
                            <div className={`${s.cell} ${weekend(item)}`} key={index}>
                                <div className={s.number}>
                                    <span className={`${s.day__number} ${currentDay(item)} ${currentMonth(item)}`}>{item.format("D")}</span>
                                </div>
                            </div>
                        )
                    })
                }
            </div>  
        </div>
        </div>
       
    )
}
export default CalendarGrid;