import React from "react";

import s from "./CalendarUsers.module.css";

const CalendarUsers = ({users})=>{
    return(
        <div className={s.wrap}>
            {
                users.map((item)=>{
                    return(
                        <div key={item.userID} className={s.user}>
                            <div className={s.img__user__wrap}>
                                <div className={s.img__user__inner}>
                                    <img src={item.imgUrl} className={s.img__user} alt="" />
                                </div>
                            </div>
                            <div className={s.text__user}>
                                <div className={s.title__wrap}>
                                    <p className={s.title} style={{color:item.color}}>{item.userName}</p>
                                </div>
                                <div className={s.work__wrap}>
                                    <p className={s.work}>{item.work}</p>
                                </div>
                            </div>
                        </div>
                       
                    )
                })
            }
        </div>
    )
}

export default CalendarUsers;