import React, { useState } from "react";
import s from "./calendar.module.css";
import CalendarGrid from "./CalendarGrid/CalendarGrid";
import CalendarMonitore from "./CalendarMonitore/CalendarMonitore";
import moment from "moment/moment";
import CalendarUsers from "./CalendarUsers/CalendarUsers";

function testDataUser(){
    let masUsers = [
        {
            userName:"Васько Володимир Олександрович",
            imgUrl:"https://img.freepik.com/free-photo/male-doctor-with-face-mask-portrait_53876-105124.jpg",
            work:"Терапевт",
            color:"#892275",
            userID:34,
            month:2,
            year:2023,
            workTime:[
                {
                    start:"09:00",
                    end:"14:00",
                    day:7,
                    cabinet:1
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:10,
                    cabinet:1
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:19,
                    cabinet:1
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:22,
                    cabinet:1
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:25,
                    cabinet:1
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:30,
                    cabinet:1
                }
            ]
        },
        {
            userName:"Халімов Сегій",
            imgUrl:"https://i.pinimg.com/736x/94/d0/6b/94d06bd2ffd2fc05e6ccc6f5bc6337dc.jpg",
            work:"Хірург",
            color:"#897275",
            userID:35,
            month:2,
            year:2023,
            workTime:[
                {
                    start:"09:00",
                    end:"14:00",
                    day:7,
                    cabinet:2
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:10,
                    cabinet:2
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:19,
                    cabinet:2
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:22,
                    cabinet:1
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:25,
                    cabinet:1
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:30,
                    cabinet:1
                }
            ]
        },
        {
            userName:"Кліменко Ганна Вікторівна",
            imgUrl:"https://image.made-in-china.com/2f0j00yhmYduMPkRkj/Disposable-Surgical-Doctor-Face-Mask-Medical-Supply.jpg",
            work:"Терапевт",
            color:"#292275",
            userID:37,
            month:2,
            year:2023,
            workTime:[
                {
                    start:"09:00",
                    end:"14:00",
                    day:5,
                    cabinet:2
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:8,
                    cabinet:2
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:17,
                    cabinet:2
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:21,
                    cabinet:1
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:24,
                    cabinet:1
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:29,
                    cabinet:1
                }
            ]
        },
        {
            userName:"Тер Юлія Жаківна",
            imgUrl:"https://thumbs.dreamstime.com/z/woman-doctor-face-mask-young-cap-surgery-room-interior-39359443.jpg",
            work:"Терапевт",
            color:"#892215",
            userID:42,
            month:2,
            year:2023,
            workTime:[
                {
                    start:"09:00",
                    end:"14:00",
                    day:3,
                    cabinet:2
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:9,
                    cabinet:2
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:18,
                    cabinet:2
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:12,
                    cabinet:1
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:11,
                    cabinet:1
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:31,
                    cabinet:1
                }
            ]
        },
        {
            userName:"Жабов-Курочкин Валентин Семенович",
            imgUrl:"https://www.westend61.de/images/0001378627pw/mature-female-doctor-wearing-protective-face-mask-with-scrubs-at-clinic-JCMF00735.jpg",
            work:"Терапевт",
            color:"#492275",
            userID:13,
            month:2,
            year:2023,
            workTime:[
                {
                    start:"09:00",
                    end:"14:00",
                    day:3,
                    cabinet:1
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:9,
                    cabinet:1
                },
                {
                    start:"09:00",
                    end:"14:00",
                    day:18,
                    cabinet:1
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:12,
                    cabinet:2
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:11,
                    cabinet:2
                },
                {
                    start:"14:00",
                    end:"17:00",
                    day:31,
                    cabinet:2
                }
            ]
        },
    ]
    return masUsers;
}


const Calendar = ()=>{
const [users,setUsers] = useState(testDataUser())
const momentStart = moment();
momentStart['_locale']['_months'] = [
    "Січень","Лютий","Березень","Квітень","Травень","Червень","Липень","Серпень","Вересень","Жовтень","Листопад","Грудень",
]
const [momentTime,setMomentTime] = useState(momentStart);
const startDay = momentTime.clone().startOf('month').startOf('week');

const prevHandler = () => setMomentTime(prev => prev.clone().subtract(1,'month'))
const nextHandler = () => setMomentTime(prev => prev.clone().add(1,'month'))
const todayHandler = () => {
    setMomentTime(momentStart)
    console.log(users)
}

    return (
        <div className={s.wrapper}>
            <div className={s.inner}>
                <CalendarMonitore 
                    momentTime = {momentTime}
                    prevHandler = {prevHandler}
                    nextHandler = {nextHandler}
                    todayHandler = {todayHandler}/>
                <CalendarGrid 
                    startDay = {startDay}
                    momentTime = {momentTime}
                    momentStart = {momentStart}/>
            </div>
            <CalendarUsers 
            users={users}/>
            
        </div>
    )
}

export default Calendar;