import React from "react";
import s from "./statistic.module.css";
const Statistic = ()=>{

    return (
        <>
            <h1>Statistic</h1>
        </>
    )
}

export default Statistic;