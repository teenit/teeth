import React, { useEffect, useState } from "react";
import { api } from "../../../functions/api";

const SetGetClinics = ()=>{
    const [state, setState] = useState([])
    
    useEffect(()=>{
        api({},"manage/get-all-clinics.php").then(e=>setState(e))
    },[])

    return(
        <div>
            {
                state.map((item)=>{
                    return(
                        <p key={item.id}>{item.clinic.name} {item.clinic.startTime}</p>
                    )
                })
            }
        </div>
    )
}

export default SetGetClinics;