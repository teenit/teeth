import React from "react";
import s from "./rozrah.module.css";
const Rozrah = ()=>{

    return (
        <>
            <h1>Розрахунок</h1>
        </>
    )
}

export default Rozrah;