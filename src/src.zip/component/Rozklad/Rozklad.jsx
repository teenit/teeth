import React from "react";
import s from "./rozklad.module.css";

const Rozklad = ()=>{

    return (
        <div className={s.wrapper}>
        <h1 className={s.title}>Rozklad</h1>
    </div>
    )
}

export default Rozklad;