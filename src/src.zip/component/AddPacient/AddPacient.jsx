import React from "react";

const AddPacient =()=>{
    return(
        <div>AddPacient</div>
    )
}
export default AddPacient;