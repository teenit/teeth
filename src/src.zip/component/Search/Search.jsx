import React from "react";
import s from "./search.module.css";
const Search = ()=>{

    return(
        <>
            <h1>Пошук</h1>
        </>
    )
}

export default Search;