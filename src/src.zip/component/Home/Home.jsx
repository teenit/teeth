import React from "react";
import s from "./home.module.css";

const Home = ()=>{

    return (
        <div className={s.wrapper}>
            <h1 className={s.title}>Home</h1>
        </div>
    )
}

export default Home;